import React from "react";
import Header from "../components/Header";
import Comments from "../components/Comments";

import Box from "../components/Tabs";

const Home = () => {
  return (
    <>
      <Header />
      <Comments />
      <Box />
    </>
  );
};

export default Home;
