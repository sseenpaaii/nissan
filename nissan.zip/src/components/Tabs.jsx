import Tab from "react-bootstrap/Tab";
import Tabs from "react-bootstrap/Tabs";

import Cars from "./Cars";
import "bootstrap/dist/css/bootstrap.min.css";

const categories = ["Electric", "Cars", "Trucks", "jeep", "Sports Cars"];

function Box() {
  return (
    <Tabs
      defaultActiveKey="profile"
      id="justify-tab-example"
      className="mb-3"
      justify
    >
      <Tab eventKey="Electric" title="Electric">
        <Cars />
      </Tab>
      <Tab eventKey="Cars" title="Cars">
        <Cars />
      </Tab>
      <Tab eventKey="Trucks" title="Trucks">
        <Cars />
      </Tab>
      <Tab eventKey="jeep" title="jeep">
        <Cars />
      </Tab>
      <Tab eventKey="Sports Cars" title="Sports Cars">
        <Cars />
      </Tab>
    </Tabs>
  );
}

export default Box;
