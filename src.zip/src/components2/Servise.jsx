import React from "react";

import {CiSettings} from 'react-icons/ci'
import { GrNotes } from "react-icons/gr"
import {MdLocalCarWash} from "react-icons/md"
import {HiReceiptPercent} from "react-icons/hi"

const Servise = () => {
    return (
      <section>
        <div>
          <CiSettings />
          <GrNotes />
          <MdLocalCarWash />
          <HiReceiptPercent />
        </div>
      </section>
    );
}

export default Servise;